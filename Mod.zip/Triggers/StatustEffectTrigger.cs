﻿using System.Threading.Tasks;
using BepInEx.Logging;

namespace PeakIntiface.Triggers
{
    internal class StatustEffectTrigger
    {
    }
}
