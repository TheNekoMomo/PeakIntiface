﻿using System.Threading.Tasks;
using BepInEx;
using BepInEx.Configuration;
using PeakIntiface.Buttplug;
using PeakIntiface.Toy;
using PeakIntiface.Triggers;


namespace PeakIntiface
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class Plugin : BaseUnityPlugin
    {
        public const string PluginGuid = "momo.peakintiface";
        public const string PluginName = "PEAK Intiface";
        public const string PluginVersion = "0.0.1";

        // Config entries
        public static ConfigEntry<bool> Enabled;
        public static ConfigEntry<string> ServerIP;
        public static ConfigEntry<int> ServerPort;
        public static ConfigEntry<float> MaximumIntensity;
        // Config entries for movement triggers
        public static ConfigEntry<bool> NormalClimbingTriggerEnabled;
        public static ConfigEntry<float> NormalClimbingTriggerMaximumIntensity;
        public static ConfigEntry<float> NormalClimbingTriggerMinimumIntensity;
        public static ConfigEntry<bool> RopeClimbingTriggerEnabled;
        public static ConfigEntry<float> RopeClimbingTriggerMaximumIntensity;
        public static ConfigEntry<float> RopeClimbingTriggerMinimumIntensity;
        public static ConfigEntry<bool> VineClimbingTriggerEnabled;
        public static ConfigEntry<float> VineClimbingTriggerMaximumIntensity;
        public static ConfigEntry<float> VineClimbingTriggerMinimumIntensity;
        public static ConfigEntry<bool> SprintingTriggerEnabled;
        public static ConfigEntry<float> SprintingTriggerMaximumIntensity;
        public static ConfigEntry<float> SprintingTriggerMinimumIntensity;

        public static ButtplugManager ButtplugManager;
        public static ToyController ToyController;
        public static MovementTrigger StaminaTrigger;

        private void Awake()
        {
            Logger.LogInfo($"{PluginName} v{PluginVersion} loading...");

            LoadConfig();

            ButtplugManager = new ButtplugManager(Logger);
            if (Enabled.Value) _ = ButtplugManager.StartReconnecting(ServerIP.Value, ServerPort.Value);
            ToyController = new ToyController(ButtplugManager, Logger);

            StaminaTrigger = new MovementTrigger(Logger);

            Logger.LogInfo($"Intiface Address: {ServerIP.Value}:{ServerPort.Value}");
            Logger.LogInfo($"{PluginName} Loaded!");
        }

        private void Update()
        {
            // Run the Trigger updates only if the plugin is enabled, the ToyController is initialized, and the ButtplugManager is connected
            if (Enabled.Value || ToyController == null || ButtplugManager.IsConnected) return;
            StaminaTrigger?.Update();
        }

        private void LoadConfig()
        {
            Enabled = Config.Bind("General", "Enabled", true, "Enable or Disable toy control");
            Enabled.SettingChanged += EnabledSettingChnaged;
            MaximumIntensity = Config.Bind("General", "MaximumIntensity", 0.5f, 
                new ConfigDescription("Maximumtoy intensity from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            ServerIP = Config.Bind("Connection", "ServerIP", "127.0.0.1", "IP address of the Intiface Server");
            ServerPort = Config.Bind("Connection", "ServerPort", 12345, "Port of the Intiface Server");

            // Load movement trigger settings
            // Normal Climbing Trigger
            NormalClimbingTriggerEnabled = Config.Bind("Triggers", "NormalClimbingTriggerEnabled", true, "Enable or Disable Normal Climbing Trigger");
            NormalClimbingTriggerMaximumIntensity = Config.Bind("Triggers", "NormalClimbingTriggerMaximumIntensity", 0.5f, 
                new ConfigDescription("Maximum intensity for Normal Climbing Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            NormalClimbingTriggerMinimumIntensity = Config.Bind("Triggers", "NormalClimbingTriggerMinimumIntensity", 0.1f,
                new ConfigDescription("Minimum intensity for Normal Climbing Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            // Rope Climbing Trigger
            RopeClimbingTriggerEnabled = Config.Bind("Triggers", "RopeClimbingTriggerEnabled", true, "Enable or Disable Rope Climbing Trigger");
            RopeClimbingTriggerMaximumIntensity = Config.Bind("Triggers", "RopeClimbingTriggerMaximumIntensity", 0.5f, 
                new ConfigDescription("Maximum intensity for Rope Climbing Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            RopeClimbingTriggerMinimumIntensity = Config.Bind("Triggers", "RopeClimbingTriggerMinimumIntensity", 0.5f,
                new ConfigDescription("Minimum intensity for Rope Climbing Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            // Vine Climbing Trigger
            VineClimbingTriggerEnabled = Config.Bind("Triggers", "VineClimbingTriggerEnabled", true, "Enable or Disable Vine Climbing Trigger");
            VineClimbingTriggerMaximumIntensity = Config.Bind("Triggers", "VineClimbingTriggerMaximumIntensity", 0.5f, 
                new ConfigDescription("Maximum intensity for Vine Climbing Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            VineClimbingTriggerMinimumIntensity = Config.Bind("Triggers", "VineClimbingTriggerMinimumIntensity", 0.5f,
                new ConfigDescription("Minimum intensity for Vine Climbing Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            // Sprinting Trigger
            SprintingTriggerEnabled = Config.Bind("Triggers", "SprintingTriggerEnabled", true, "Enable or Disable Sprinting Trigger");
            SprintingTriggerMaximumIntensity = Config.Bind("Triggers", "SprintingTriggerMaximumIntensity", 0.5f, 
                new ConfigDescription("Maximum intensity for Sprinting Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
            SprintingTriggerMinimumIntensity = Config.Bind("Triggers", "SprintingTriggerMinimumIntensity", 0.5f,
                new ConfigDescription("Minimum intensity for Sprinting Trigger from 0.0 to 1.0", new AcceptableValueRange<float>(0.01f, 1)));
        }

        private void EnabledSettingChnaged(object sender, System.EventArgs e)
        {
            if (Enabled.Value)
            {
                _ = ButtplugManager.StartReconnecting(ServerIP.Value, ServerPort.Value);
            }
            else
            {
                _ = ButtplugManager.DisconnectAsync();
            }
        }

        private void OnApplicationQuit()
        {
            if (ButtplugManager == null)
            {
                return;
            }

            Logger.LogInfo(
                "PEAK is closing. Shutting down Intiface..."
            );


            try
            {
                Task shutdownTask =
                    ButtplugManager.ShutdownAsync();

                if (!shutdownTask.Wait(2000))
                {
                    Logger.LogWarning(
                        "Intiface shutdown timed out. Allowing PEAK to close."
                    );
                }
            }
            catch (System.Exception ex)
            {
                Logger.LogWarning(
                    $"Error during Intiface shutdown: {ex.Message}"
                );
            }
        }
    }
}